import { getExportSettings } from "./utils/export_settings/getExportSettingsFile.js";
import { exportToPPT } from "./utils/export_modes/exportToPPT.js";
import { exportToPDF } from "./utils/export_modes/exportToPDF.js";
import exporter from "highcharts-export-server"



process.on("message", message => {
    // dataArray is the array which contains all the necessary info about 
    // chart (chartType, reportObjDetails, data) 
    let arrayInput = message.dataArray;
    processRequest(arrayInput).then(result => {
        process.send({message:result});
        process.exit();
    }).catch((err)=>{
        console.log(err);
        process.exit();
    })

})

const exportToImg = (exportSettings)=>{
    return new Promise((resolve, reject)=>{
    
        exporter.export(exportSettings, function (err, res) {
            //If the output is not PDF or SVG, it will be base64 encoded (res.data).
            //If the output is a PDF or SVG, it will contain a filename (res.filename).
            
            if(res.data){
                resolve(res.data);
            }
            else{
                console.log(err)
                reject(err);
            }
            
        });
    })
}


const exportLoop = (reqJSONArray)=>{
    return new Promise((resolve, reject)=>{
        const toBeDone = reqJSONArray.length;
        let done = 0;
        let resultArray = new Array(toBeDone);
        for(let i = 0; i < toBeDone; i++){
            let arrayData = reqJSONArray[i];

            // pass parameter to getExportSettings
            let exportSettings = getExportSettings(arrayData);
            
            exportToImg(exportSettings).then(response => {
                resultArray[i] = response;
                console.log("" + process.pid + " done", i);
                done += 1;
                if(done === toBeDone){
                    
                    resolve(resultArray);
                }
            })
            .catch((err)=>{
                console.log(err);
                reject(err);
            })
        }
    })
    
}



const processRequest = (dataToProcess)=>{
    return new Promise ((resolve, reject)=>{
        var reqJSONArray = dataToProcess;
        exporter.initPool({timeoutThreshold : 10000});
        
        exportLoop(reqJSONArray).then(response => {  
            exportToPPT(response).then(()=>{
                resolve({
                    data : response
                });
            }).catch(err=>{
                console.log(err);
                reject({notok : "ppt doesnot work"});
            });          
            
        }).catch(err=>{
            console.log(err);
            reject({
                notOk : true,
                
            }); 
        })
    }) 

}