/* 
This file is the MAIN file it initializes grp of processes
which takes request and split itself to child processes 

                NUM_OF_WORKER_PROCESS == NUM_CPU 

              -> Worker process ->-> splits to form new child processs
              -> Worker process ->-> splits to form new child processs
              -> Worker process ->-> splits to form new child processs
              -> Worker process ->-> splits to form new child processs
Master Process
              -> Worker process ->-> splits to form new child processs
              -> Worker process ->-> splits to form new child processs
              -> Worker process ->-> splits to form new child processs
              -> Worker process ->-> splits to form new child processs
this is helpful as it is like we have 8 main workers which take request separately 
and divide it further smaller processes this increases the availability 
*/

import express from "express";
import cluster from "cluster";
import { cpus } from "os";
import { fork } from "child_process";
import dotenv from "dotenv";
dotenv.config();

const app = express();
const num_cpu = cpus().length;
const PORT = process.env.PORT;

// app.use(morgan.format("combined"));

if (cluster.isMaster) {
  console.log("Master Process:", process.pid);
  for (let i = 0; i < num_cpu; i++) {
    cluster.fork();
  }
} else {
  app.listen(PORT, () => {
    console.log("Worker Process id " + process.pid);
  });

  app.use(express.json());

  app.post("/", (req, res) => {
    const childProcess = fork("./childProcess.js");
    childProcess.send(req.body);
    childProcess.on("message", (response) => {
      res.json(response.message);
    });
  });
}

cluster.on("exit", (worker) => {
  console.log(`worker process ${worker.process.pid} died.`);
  console.log("starting new worker");
  cluster.fork();
});
