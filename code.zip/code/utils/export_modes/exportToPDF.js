import pkg from 'jspdf';
const { jsPDF } = pkg;
import sizeOf from "image-size";
const getImgDim = (img)=>{
    var img = Buffer.from(img, 'base64');
    var dimensions = sizeOf(img);
    // console.log(dimensions.width, dimensions.height);
    return dimensions;
}
export const exportToPDF = (imgArrayBase64, imgFormat = 'JPEG')=>{
    
    const doc = new jsPDF({
        orientation: "landscape",
      });
    
    for(let i = 0; i < imgArrayBase64.length; i++){
        // addImage(imageData, format, x, y, width, height, alias, compression, rotation)
        doc.addImage(imgArrayBase64[i], imgFormat, 0, 0, 150, 150); 
    }
    
    doc.save("" + process.pid + "_PDF.pdf");
}
// module.exports = {
//     exportToPDF
// }