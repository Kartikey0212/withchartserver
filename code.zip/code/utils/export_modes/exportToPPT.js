import pptxgen from "pptxgenjs";
export const exportToPPT = (imgArrayBase64)=>{
    return new Promise((resolve, reject)=>{
        let pres = new pptxgen();

        let dataFormat = "img/png;base64,";
        for(let i = 0; i < imgArrayBase64.length; i++){
            let slide = pres.addSlide();
            slide.addImage({  
                x: 0, 
                y: 0, 
                w: "100%", 
                h: "100%", 
                data: dataFormat + imgArrayBase64[i] 
            });
        }
        let pptName = "./PPTs/" + process.pid + "_child_ppt"
        pres.writeFile({ fileName: pptName }).then(()=>{
            resolve();
        }).catch(err=>{
            reject(err);
        });

    })
    
}
